﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;

public partial class PromotionStatus : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    
    protected void Button_Sub_Click(object sender, EventArgs e)
    {
        if (IsPostBack)
        {
            SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
            conn.Open();
            string checkuser = "select count(*) from [Promotions] where VehicleNo ='" + TextBox_Vid.Text + "'";
            SqlCommand com = new SqlCommand(checkuser, conn);
            int temp = Convert.ToInt32(com.ExecuteScalar().ToString());
            if (temp != 0)
            {
                Label_U1.Visible = true;
                Label_U1.Text = "Here is your status";
            }
            else
            {
                Label_U1.Visible = true;
                Label_U1.Text = "Invalid vehicle number";
            }

        }
    }
    protected void Button_C_Click(object sender, EventArgs e)
    {
        Response.Redirect("CustomerHome.aspx");
    }

}