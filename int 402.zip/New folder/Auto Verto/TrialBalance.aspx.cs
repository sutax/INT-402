﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Windows.Forms;

public partial class TrialBalance : System.Web.UI.Page
{
    string cs = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
    SqlConnection con = null;
    SqlCommand cmd = null;
    private SqlConnection convar;
    private SqlCommand comvar;
    private SqlDataReader reader;
    protected void Page_Load(object sender, EventArgs e)
    {
        Label7.Text = "";
        Label9.Text = "";

        convar = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        comvar = new SqlCommand("select SUM(TotalAmount) AS Total from Expenses where Month='" + DropDownListMonth.Text + "'", convar);
        convar.Open();
        reader = comvar.ExecuteReader();
        reader.Read();

        Label8.Text = reader[0].ToString() + "";
        comvar.Dispose();
        reader.Close();

        convar = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        comvar = new SqlCommand("select SUM(TotalBill) AS Total from Sales where Month='" + DropDownListMonth.Text + "'", convar);
        convar.Open();
        reader = comvar.ExecuteReader();
        reader.Read();
        Label6.Text = reader[0].ToString() + "";
        comvar.Dispose();
        reader.Close();

        if (!IsPostBack)
        {

            filldata();
        }
        }

    private void filldata()
    {
        reader = comvar.ExecuteReader();
        while (reader.Read())
        {
            DropDownListMonth.Items.Add(reader[0].ToString());
        }
        comvar.Dispose();
        reader.Close();
    }

    protected void DropDownListMonth_SelectedIndexChanged(object sender, EventArgs e)
    {
        comvar = new SqlCommand("select SUM(TotalBill) AS Total from Sales where Month='" + (DropDownListMonth.SelectedItem.Value) + "'", convar);
        reader = comvar.ExecuteReader();
        reader.Read();
        Label6.Text = reader[0] + "";
        comvar.Dispose();
        reader.Close();

        comvar = new SqlCommand("select SUM(TotalAmount) AS Total from Expenses where Month='" + (DropDownListMonth.SelectedItem.Value) + "'", convar);
        reader = comvar.ExecuteReader();
        reader.Read();
        Label8.Text = reader[0] + "";
        comvar.Dispose();
        reader.Close();
    }

    protected void Button_Cal_Click(object sender, EventArgs e)
    {
        try
        {
            int b = Convert.ToInt32(Label6.Text);
            int c = Convert.ToInt32(Label8.Text);
            if (b - c >= 0)
            {
                Label7.Text = Convert.ToString(b - c);
            }
            else
                if (b - c < 0)
                {
                    Label9.Text = Convert.ToString(-(b - c));
                }
        }
        catch (Exception ex)
        {
            MessageBox.Show("No data is present", "", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        try
        {
            con = new SqlConnection(cs);
            con.Open();
            string cb = "update TrialBalance set Month = '" + DropDownListMonth.Text + "', Expenses= '" + Label8.Text + "', Profit= '" + Label7.Text + "', Income= '" + Label6.Text + "', Loss= '" + Label9.Text + "' where Month='" + DropDownListMonth.Text + "'";
            cmd = new SqlCommand(cb);
            cmd.Connection = con;
            cmd.ExecuteReader();
            con.Close();
            {
                Label_U1.Visible = true;
                Label_U1.Text = "Calculated successfully";
            }
        }
        catch (Exception ex)
        {
            Response.Write("Error" + ex.ToString());
        }
    }
}