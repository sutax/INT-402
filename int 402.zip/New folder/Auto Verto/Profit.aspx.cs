﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

public partial class Profit : System.Web.UI.Page
{
    string cs = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
    SqlConnection con = null;
    SqlCommand cmd = null;
    private SqlConnection convar;
    private SqlCommand comvar;
    private SqlDataReader reader;

    protected void Page_Load(object sender, EventArgs e)
    {
        convar = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        comvar = new SqlCommand("select SUM(TotalAmount) AS Total from Expenses", convar);
        convar.Open();
        reader = comvar.ExecuteReader();
        reader.Read();

        Label9.Text = reader[0].ToString() + "";
        comvar.Dispose();
        reader.Close();

        convar = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        comvar = new SqlCommand("select SUM(TotalBill) AS Total from Sales", convar);
        convar.Open();
        reader = comvar.ExecuteReader();
        reader.Read();

        Label11.Text = reader[0].ToString() + "";
        comvar.Dispose();
        reader.Close();

        convar = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        comvar = new SqlCommand("select SUM(TotalSaleRs) AS Total from Purchases", convar);
        convar.Open();
        reader = comvar.ExecuteReader();
        reader.Read();

        Label8.Text = reader[0].ToString() + "";

        comvar.Dispose();
        reader.Close();
        Label10.Text = "";
    }
    protected void Button1_Click1(object sender, EventArgs e)
    {
        try
        {
            int b = Convert.ToInt32(Label8.Text);
            int c = Convert.ToInt32(Label9.Text);
            int g = Convert.ToInt32(Label11.Text);
            //   int h = Convert.ToInt32(Label10.Text);
            if (g - (b + c) >= 0)
            {
                Label10.Text = Convert.ToString(g - (b + c));
            }
            else
                if (g - (b + c) < 0)
                {
                    Label14.Text = Convert.ToString(-(g - (b + c)));
                }
        }
        catch (Exception ex)
        {
            Label_U1.Text = ("Data not found");
        }
    }
    protected void Print_Click(object sender, EventArgs e)
    {
        try
        {
            con = new SqlConnection(cs);
            con.Open();
            string cb = "update Profit set OStock = '" + Label7.Text + "', Pur= '" + Label8.Text + "', Exp= '" + Label9.Text + "', NPro= '" + Label10.Text + "', Sales= '" + Label11.Text + "', CStock= '" + Label12.Text + "', NLoss= '" + Label14.Text + "'";
            cmd = new SqlCommand(cb);
            cmd.Connection = con;
            cmd.ExecuteReader();
            con.Close();

            Response.Redirect("ReportProfit.aspx");

        }
        catch (Exception ex)
        {
            Response.Write("Error" + ex.ToString());
        }
    }
    protected void Button_C_Click(object sender, EventArgs e)
    {
        Response.Redirect("AdminHome.aspx");
    }
}