﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Windows.Forms;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Drawing;
using System.Data;
using System.Web.Security;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls.WebParts;

public partial class Categories : System.Web.UI.Page
{
    string cs = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
    
    protected void Page_Load(object sender, EventArgs e)
    {
        if (IsPostBack)
        {
            SqlConnection conn1 = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
            conn1.Open();
            string checkcata = "select count(*) from [Stock] where Category ='" + TextBox_Cate.Text + "'";
            SqlCommand com1 = new SqlCommand(checkcata, conn1);
            int temp = Convert.ToInt32(com1.ExecuteScalar().ToString());
            if (temp != 0)
            {
                Label_U1.Visible = true;
                Label_U1.Text = "Alredy exists";
               
            }

            conn1.Close();
        }
    }
    protected void Button_Add_Click(object sender, EventArgs e)
    {
        try
        {
            SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
            conn.Open();
            string insertQuerry = "insert into Stock (Category, [Unit Purchase Cost], [Unit Sale Price]) values(@cate, @ucost, @usp)";
            SqlCommand com = new SqlCommand(insertQuerry, conn);

            com.Parameters.AddWithValue("@cate", TextBox_Cate.Text);
            com.Parameters.AddWithValue("@ucost", TextBox_UPrice.Text);
            com.Parameters.AddWithValue("@usp", TextBox_USPrice.Text);
            com.ExecuteNonQuery();
            {
                Label_U1.Visible = true;
                Label_U1.Text = "Added successfully";
            }

            TextBox_Cate.Text = "";
            TextBox_UPrice.Text = "";
            TextBox_USPrice.Text = "";
            conn.Close();
        }

        catch (Exception ex)
        {
            Response.Write("Error" + ex.ToString());
        }
    }
    protected void Button_C_Click(object sender, EventArgs e)
    {
        Response.Redirect("AdminHome.aspx");
    }
    protected void ButtonV_Click(object sender, EventArgs e)
    {
        Response.Redirect("ViewCategory.aspx");
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        Response.Redirect("EditCategory.aspx");
    }
}