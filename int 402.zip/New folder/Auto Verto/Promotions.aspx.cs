﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using GsmComm.GsmCommunication;
using GsmComm.Interfaces;
using GsmComm.PduConverter;
using GsmComm.Server;
using System.IO;
using System.Management;

public partial class Promotions : System.Web.UI.Page
{
    string cs = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
    SqlConnection con = null;
    SqlCommand cmd = null;
    private SqlConnection convar;
    private SqlCommand comvar;
    private SqlDataReader reader;

    GsmCommMain comm;
    public Promotions()
    {
        comm = new GsmCommMain(5, 115200);
    }
    protected void Page_Load(object sender, EventArgs e)
    {
        convar = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        convar.Open();
        Label_U1.Visible = false;
        if (!IsPostBack)
        {

            filldata();
        }

        TextBox_Pno.Enabled = false;
    }
    private void filldata()
    {
        comvar = new SqlCommand("select VehicleNo from AddCustomer", convar);
        if (convar.State == System.Data.ConnectionState.Closed)
        {
            convar.Open();
        }
        reader = comvar.ExecuteReader();
        DropDownList_Vid.Items.Clear();
        while (reader.Read())
        {
            DropDownList_Vid.Items.Add(reader[0].ToString());
        }
        comvar.Dispose();
        reader.Close();

    }
    protected void Button_Send_Click(object sender, EventArgs e)
    {
         try
        {
            SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
            conn.Open();
            string insertQuerry = "insert into Promotions (CustomerName, VehicleNo, PhoneNo, Message) values(@cname, @vnum, @pno, @msg)";
            SqlCommand com = new SqlCommand(insertQuerry, conn);

            com.Parameters.AddWithValue("@cname", TextBox_Cname.Text);
            com.Parameters.AddWithValue("@vnum", DropDownList_Vid.Text);
            com.Parameters.AddWithValue("@pno", TextBox_Pno.Text);
            com.Parameters.AddWithValue("@msg", TextBox_Msg.Text);
            com.ExecuteNonQuery();
            {
                Label_U1.Visible = true;
                Label_U1.Text = "Sent successfully";
            }
            conn.Close();
        }

        catch (Exception ex)
        {
            Response.Write("Error" + ex.ToString());
        }

        try
        {
            comm.Open();
            SmsSubmitPdu pdu;
            pdu = new SmsSubmitPdu(TextBox_Msg.Text, TextBox_Pno.Text, "");
            {
                byte dcs;
                dcs = DataCodingScheme.Class0_16Bit;
                dcs = DataCodingScheme.NoClass_7Bit;
                pdu = new SmsSubmitPdu(TextBox_Msg.Text, TextBox_Pno.Text, "", dcs);
            }
            {
                comm.SendMessage(pdu);
            }
        }
        catch (Exception ex)
        {
            MessageBox.Show("Send error:" + ex.Message, "Sms sender", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
        Cursor.Current = Cursors.Default;
        comm.Close();

    }

    protected void Button_Close_Click(object sender, EventArgs e)
    {
        Response.Redirect("Promotions.aspx");

    }

    protected void DropDownList_Vid_SelectedIndexChanged(object sender, EventArgs e)
    {
        Label_U1.Text = "";
        comvar = new SqlCommand("select PhoneNo from AddCustomer where VehicleNo=" + (DropDownList_Vid.SelectedItem.Value), convar);
        reader = comvar.ExecuteReader();
        reader.Read();

        TextBox_Pno.Text = reader[0] + "";

        comvar.Dispose();
        reader.Close();
    }
    protected void Button_View_Click1(object sender, EventArgs e)
    {
        Response.Write("AdminHome");
    }
}