﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using GsmComm.GsmCommunication;
using GsmComm.Interfaces;
using GsmComm.PduConverter;
using GsmComm.Server;
using System.IO;
using System.Management;

public partial class DoorStepReply : System.Web.UI.Page
{
    string cs = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
    SqlConnection con = null;
    SqlCommand cmd = null;
    private SqlConnection convar;
    private SqlCommand comvar;
    private SqlDataReader reader;

     GsmCommMain comm;
     public DoorStepReply()
     {
         comm = new GsmCommMain(5, 115200);
     }
    protected void Page_Load(object sender, EventArgs e)
    {
         convar = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        convar.Open();
        Label_U1.Visible = false;
        if (!IsPostBack)
        {

            filldata();
        }

        TextBox_Pno.Enabled = false;
        }
    private void filldata()
    {
        comvar = new SqlCommand("select VehicleNo from DoorStepRequest", convar);
        if (convar.State == System.Data.ConnectionState.Closed)
        {
            convar.Open();
        }
        reader = comvar.ExecuteReader();
        DropDownList_Vid.Items.Clear();
        while (reader.Read())
        {
            DropDownList_Vid.Items.Add(reader[0].ToString());
        }
        comvar.Dispose();
        reader.Close();
    
    }
    protected void Button_Add_Click(object sender, EventArgs e)
    {
        try
        {
            SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
            conn.Open();
            string insertQuerry = "insert into DoorStepReply (VehicleNo, Message) values(@vnum, @msg)";
            SqlCommand com = new SqlCommand(insertQuerry, conn);

            com.Parameters.AddWithValue("@vnum", DropDownList_Vid.Text);
            com.Parameters.AddWithValue("@msg", TextBox_Msg.Text);
            com.ExecuteNonQuery();
            {
                Label_U1.Visible = true;
                Label_U1.Text = "Sent successfully";
            }
            conn.Close();
        }

        catch (Exception ex)
        {
            Response.Write("Error" + ex.ToString());
        }

        try
        {
            comm.Open();
            SmsSubmitPdu pdu;
            pdu = new SmsSubmitPdu(TextBox_Msg.Text, TextBox_Pno.Text, "");
            {
                byte dcs;
                dcs = DataCodingScheme.Class0_16Bit;
                dcs = DataCodingScheme.NoClass_7Bit;
                pdu = new SmsSubmitPdu(TextBox_Msg.Text, TextBox_Pno.Text, "", dcs);
            }
            {
                comm.SendMessage(pdu);
            }
        }
        catch (Exception ex)
        {
            MessageBox.Show("Send error:" + ex.Message, "Sms sender", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
            Cursor.Current = Cursors.Default;
        comm.Close();

        try
        {

            int RowsAffected = 0;
            con = new SqlConnection(cs);
            con.Open();
            string cq = "delete from DoorStepRequest where VehicleNo=@vnum;";
            cmd = new SqlCommand(cq);
            cmd.Connection = con;
            cmd.Parameters.Add(new SqlParameter("@vnum", System.Data.SqlDbType.VarChar, 20, "VehicleNo"));
            cmd.Parameters["@vnum"].Value = DropDownList_Vid.SelectedItem.ToString();
            RowsAffected = cmd.ExecuteNonQuery();

            if (RowsAffected > 0)
            {
                Label_U2.Visible = true;
                Label_U2.Text = "Request moved from list";
            }
            else
            {
                Label_U2.Visible = false;
                Label_U2.Text = "Not Moved";
            }

            con.Close();

        }
        catch (Exception ex)
        {

            Label_U2.Visible = true;
            Label_U2.Text = "There is no data to move"+ex.ToString();
        }
    }
}