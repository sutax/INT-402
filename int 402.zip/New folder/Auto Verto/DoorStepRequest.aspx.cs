﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;

public partial class DoorStepRequest : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        TextBox_Date.Text = DateTime.Today.ToShortDateString();
        TextBox_Date.Enabled = false;
    }
    protected void Button_Add_Click(object sender, EventArgs e)
    {
        try
        {

            SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
            conn.Open();
            string insertQuerry = "insert into DoorStepRequest (CustomerName, PhoneNo, VehicleNo, Gender, Address, Service, Date) values(@cname, @pnum, @vnum, @gender, @address, @serv, @date)";
            SqlCommand com = new SqlCommand(insertQuerry, conn);

            com.Parameters.AddWithValue("@cname", TextBox_Cname.Text);
            com.Parameters.AddWithValue("@pnum", TextBox_Pno.Text);
            com.Parameters.AddWithValue("@vnum", TextBox_Vid.Text);
            com.Parameters.AddWithValue("@gender", DropDownList_Gender.SelectedItem.ToString());
            com.Parameters.AddWithValue("@address", TextBox_Add.Text);
            com.Parameters.AddWithValue("@date", TextBox_Date.Text);
            com.Parameters.AddWithValue("@serv", DropDownList_Service.SelectedItem.ToString());
            com.ExecuteNonQuery();
            {
                Label_U1.Visible = true;
                Label_U1.Text = "Submitted successfully...! Please check your status within 24 hours";
            }
            TextBox_Cname.Text = "";
            TextBox_Pno.Text = "";
            TextBox_Vid.Text = "";
            TextBox_Date.Text = "";
            TextBox_Add.Text = "";
            Button_Add.Enabled = false;
            conn.Close();
        }
        catch (Exception ex)
        {
            Response.Write("Error" + ex.ToString());
        }
    }
protected void Button_C_Click(object sender, EventArgs e)
    {
        Response.Redirect("CustomerHome.aspx");
    }

    protected void Button_Ref_Click(object sender, EventArgs e)
    {
        Response.Redirect("DoorStepRequest.aspx");
    }
}