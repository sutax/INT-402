﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Windows.Forms;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Drawing;
using System.Data;
using System.Web.Security;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls.WebParts;

public partial class EditCategory : System.Web.UI.Page
{
    string cs = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
    SqlConnection con = null;
    SqlCommand cmd = null;
    private SqlConnection convar;
    private SqlCommand comvar;
    private SqlDataReader reader;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (IsPostBack)
        {
            SqlConnection conn1 = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
            conn1.Open();
            string checkcata = "select count(*) from [Stock] where Category ='" + TextBox_Cate.Text + "'";
            SqlCommand com1 = new SqlCommand(checkcata, conn1);
            int temp = Convert.ToInt32(com1.ExecuteScalar().ToString());
            if (temp != 0)
            {
                Label_U1.Visible = true;
                Label_U1.Text = "Alredy exists";
             
            }
            
            conn1.Close();
        }
        Button_U.Enabled = false;
        convar = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        convar.Open();
        Label_U1.Visible = false;
        if (!IsPostBack)
        {

            filldata();
        }

        TextBox_Cate.Enabled = false;
        TextBox_UPrice.Enabled = false;
        TextBox_USPrice.Enabled = false;
    }
    private void filldata()
    {
        comvar = new SqlCommand("select [Category] from Stock", convar);
        if (convar.State == System.Data.ConnectionState.Closed)
        {
            convar.Open();
        }
        reader = comvar.ExecuteReader();
        DropDownListE.Items.Clear();
        while (reader.Read())
        {
            DropDownListE.Items.Add(reader[0].ToString());
        }
        comvar.Dispose();
        reader.Close();
    }

    protected void Button_Add_Click(object sender, EventArgs e)
    {

        try
        {
            SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
            conn.Open();
            string insertQuerry = "insert into Stock (Category, [Unit Purchase Cost]) values(@cate, @uprice)";
            SqlCommand com = new SqlCommand(insertQuerry, conn);

            com.Parameters.AddWithValue("@cata", TextBox_Cate.Text);
            com.Parameters.AddWithValue("@uprice", TextBox_UPrice.Text);
            com.ExecuteNonQuery();
            {
                Label_U1.Visible = true;
                Label_U1.Text = "Added successfully";
            }

            TextBox_Cate.Text = "";
            TextBox_UPrice.Text = "";
            conn.Close();
        }

        catch (Exception ex)
        {
            Response.Write("Error" + ex.ToString());
        }
    }

    protected void Button_C_Click(object sender, EventArgs e)
    {
        Response.Redirect("Catagories.aspx");
    }
    protected void ButtonV_Click(object sender, EventArgs e)
    {
        Response.Redirect("ViewCatagory.aspx");
    }
    protected void Button_E_Click(object sender, EventArgs e)
    {
        Button_U.Enabled = true;
        TextBox_Cate.Enabled = true;
        TextBox_UPrice.Enabled = true;
        TextBox_USPrice.Enabled = true;
    }

    protected void Button_U_Click(object sender, EventArgs e)
    {
        try
        {
            con = new SqlConnection(cs);
            con.Open();
            string cb = "update Stock set Category = '" + TextBox_Cate.Text + "', [Unit Purchase Cost]= '" + TextBox_UPrice.Text + "', [Unit Sale Price]= '" + TextBox_USPrice.Text + "' where Category='" + DropDownListE.SelectedValue.ToString() + "'";
            cmd = new SqlCommand(cb);
            cmd.Connection = con;
            cmd.ExecuteReader();
            con.Close();
            {
                Label_U1.Visible = true;
                Label_U1.Text = "Updated successfully";
            }
            Button_U.Enabled = false;
            TextBox_Cate.Enabled = false;
            TextBox_UPrice.Enabled = false;
            TextBox_USPrice.Enabled = false;
        }
        catch (Exception ex)
        {
            Response.Write("Error" + ex.ToString());
        }
    }
    protected void DropDownListE_SelectedIndexChanged(object sender, EventArgs e)
    {
        Label_U1.Text = "";
        comvar = new SqlCommand("select Category, [Unit Purchase Cost], [Unit Sale Price] from Stock where Category='" + (DropDownListE.SelectedItem.Value) + "'", convar);
        reader = comvar.ExecuteReader();
        reader.Read();
        TextBox_Cate.Text = reader[0] + "";
        TextBox_UPrice.Text = reader[1] + "";
        TextBox_USPrice.Text = reader[2] + "";

        comvar.Dispose();
        reader.Close();
    }
}